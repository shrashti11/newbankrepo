#!/bin/bash
rm -rf /usr/share/tomcat/webapps/movie-service*
