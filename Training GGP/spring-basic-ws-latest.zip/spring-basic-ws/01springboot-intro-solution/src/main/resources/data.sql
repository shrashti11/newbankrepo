insert into account(name,isactive,city,country,balance,emailaddress) values('shiva',true,'Bangalore','India',10000,'sivaprasad.valluru@gmail.com');
	insert into account(name,isactive,city,country,balance,emailaddress) values('Prasad',true,'Hyderabad','India',20000,'siva@gmail.com');
